export class UpdateUserDto {
  readonly username?: string;
  readonly password?: string;
}
