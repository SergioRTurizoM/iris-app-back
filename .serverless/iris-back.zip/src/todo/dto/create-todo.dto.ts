export class CreateTodoDto {
  readonly text: string;
}
